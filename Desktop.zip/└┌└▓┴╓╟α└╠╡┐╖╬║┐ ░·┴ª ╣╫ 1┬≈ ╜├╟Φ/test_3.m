test_1 % ���, ���л�, ǥ������

x = -8:0.2:8;
y = -6:0.2:8;

[X, Y] = meshgrid(x, y);
XY = [X(:) Y(:)];

mv1 = mvnpdf(XY, MX1, CX1);
mv2 = mvnpdf(XY, MX2, CX2);
mv3 = mvnpdf(XY, MX3, CX3);

% p(w1), p(w2), p(w3) ���� %(4)������%
pw1 = size(X1)/(size(X1)+size(X2)+size(X3));
pw2 = size(X2)/(size(X1)+size(X2)+size(X3));
pw3 = size(X3)/(size(X1)+size(X2)+size(X3));

% px �� %(6)�� ����%
px = (mv1*pw1) + (mv2*pw2) + (mv3*pw3);

Z = reshape(px, length(y), length(x));
% surf(X, Y, Z);

X = [X1;X2;X2];

pxw1 = length(px)/pw1;
pxw2 = length(px)/pw2;
pxw3 = length(px)/pw3;

ppxw1 = pxw1 - pxw2;
ppxw2 = pxw2 - pxw3;
ppxw3 = pxw3 - pxw1;