test_1 % 1), 2) �� ������ ��
% sigma = ���л�, mu = ���
% B�� �߻� ���� ���� ����� Ȯ��

% rnd1 = randn(200,2);

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
x = -8:0.1:8; % ���?
y = -6:0.1:8;

[X, Y] = meshgrid(x, y);
XY = [X(:) Y(:)];

% z = CX1*MX1; --> mv1���� ����
mv1 = mvnpdf(XY, MX1, CX1);
mv2 = mvnpdf(XY, MX2, CX2);
mv3 = mvnpdf(XY, MX3, CX3);

Z1 = reshape(mv1, length(y), length(x));
Z2 = reshape(mv2, length(y), length(x));
Z3 = reshape(mv3, length(y), length(x));

% x1��
figure(1);
surf(X, Y, Z1);

% x2��
figure(2);
surf(X, Y, Z2);

% x3��
figure(3);
surf(X, Y, Z3);

% ��ü �� �����ֱ�
figure(4);
surf(X, Y, Z1);
hold on;
surf(X, Y, Z2);
surf(X, Y, Z3);
hold off;

xlabel('x'); ylabel('y'); zlabel('z')




% h = [mv1 mv2 mv3];
% L = [];
% for i=1:size(h)
%     PX = px(i);
%     PXW1 = mv1(i);
%     PXW2 = mv2(i);
%     PXW3 = mv3(i);
% end
% 
% px1w = PXW1 - PXW2;
% px2w = PXW2 - PXW3;
% px3w = PXW3 - PXW1;


% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 

% B�� �߻� ���� ���� ���
% test1 = mvnrnd(MX1,CX1,200);
% test2 = mvnrnd(MX2,CX2,200);
% test3 = mvnrnd(MX3,CX3,200);
% 
% test_mx1 = mean(test1);
% test_mx2 = mean(test2);
% test_mx3 = mean(test3);
% 
% test_cx1 = cov(test1);
% test_cx2 = cov(test2);
% test_cx3 = cov(test3);
% 
% mv_test1 = mvnpdf(test1, test_mx1, test_cx1);
% mv_test2 = mvnpdf(test2, test_mx2, test_cx2);
% mv_test3 = mvnpdf(test3, test_mx3, test_cx3);
% 
% % p(w1), p(w2), p(w3) ���� test
% tepw1 = size(test1)/(size(test1)+size(test2)+size(test3));
% tepw2 = size(test2)/(size(test1)+size(test2)+size(test3));
% tepw3 = size(test3)/(size(test1)+size(test2)+size(test3));
% 
% % px ��
% px = (mv_test1*tepw1) + (mv_test2*tepw2) + (mv_test3*tepw3);




% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 

% B�� �߻� ���� ���� ���
% test1 = mvnrnd(MX1,CX1,200);
% test2 = mvnrnd(MX2,CX2,120);
% test3 = mvnrnd(MX3,CX3,180);
% 
% test_mx1 = mean(test1);
% test_mx2 = mean(test2);
% test_mx3 = mean(test3);
% 
% test_cv1 = cov(test1);
% test_cv2 = cov(test2);
% test_cv3 = cov(test3);
% 
% mv_test1 = mvnpdf(test1, test_mx1, test_cv1);
% mv_test2 = mvnpdf(test2, test_mx2, test_cv2);
% mv_test3 = mvnpdf(test3, test_mx3, test_cv3);
% 
% tepw1 = size(test1)/(size(X1)+size(test1)); % p(w1) -> ?
% tepw2 = size(test2)/(size(X2)+size(test2)); % p(w2) -> ?
% tepw3 = size(test3)/(size(X3)+size(test3)); % p(w3) -> ?


% pxw_1 = ((test1|X1).*X1)./test1;
% pxw_2 = ((test2|X2).*X2)./test2;
% pxw_3 = ((test3|X3).*X3)./test3;
% 
% pxw_11 = (mv1.^mv_test1)./mv_test1;
% pxw_22 = ((test2|X2).*X2)./test2;
% pxw_33 = ((test3|X3).*X3)./test3;