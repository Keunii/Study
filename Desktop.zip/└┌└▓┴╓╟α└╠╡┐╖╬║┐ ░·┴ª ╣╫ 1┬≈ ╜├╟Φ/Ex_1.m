tennis

x = min(a(:,1)):10:max(a(:,1));
y = min(a(:,2)):10:max(a(:,2));
[X, Y] = meshgrid(x, y);
xy = [X(:) Y(:)];

% xm = a(:,1);
% ym = a(:,2);
am = mean(a);
ac = cov(a, 1); % ������

amv = mvnpdf(xy, am, ac);
Z = reshape(amv, length(y), length(x));
surf(X, Y, Z);