h1  = -8:0.5:8; % x��
h2 = -8:0.5:8; % y��
[X, Y] = meshgrid(h1, h2);
% XX = [X(:) Y(:)];

rnd1 = randn(200,2);

% �⺻ ������
% X1, X2, X3

% ��հ�
MX1 = mean(X1);
MX2 = mean(X2);
MX3 = mean(X3);

% ǥ������
SX1 = std(X1);
SX2 = std(X2);
SX3 = std(X3);

% ���л�
CX1 = cov(X1);
CX2 = cov(X2);
CX3 = cov(X3);

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 

% sigma = ���л�, mu = ���
% B�� �߻� ���� ���� ����� Ȯ��
mv1 = mvnpdf(X1, MX1, CX1);
% z = reshape(mv1, length(X), length(Y));

mv2 = mvnpdf(X2, MX2, CX2);
mv3 = mvnpdf(X3, MX3, CX3);

% B�� �߻� ���� ���� ���
test1 = mvnrnd(MX1,CX1,200);
test2 = mvnrnd(MX2,CX2,200);
test3 = mvnrnd(MX3,CX3,200);


% p(w1), p(w2), p(w3) ����
pw1 = size(X1)/(size(X1)+size(test1));
pw2 = size(X2)/(size(X2)+size(test2));
pw3 = size(X3)/(size(X3)+size(test3));


% figure(1);
% sca = scatter3(X1(:,1), X1(:,2), mv1);
% 
% figure(2);
% sca2 = scatter3(X2(:,1), X2(:,2), mv2);
% 
% figure(3);
% sca3 = scatter3(X3(:,1), X3(:,2), mv3);

% mu = mean(test1);
% sigma = cov(test1);
% mv1 = mvnpdf(test1,  mu, sigma);

% Z = meshgrid(mv1);
% [X,Y] = meshgrid(h1, h2);
% Z = (X1(:,1) .^ X1(:,2)) ./ X1(:,2);

% scatter3(X1(:,1), X1(:,2), mv1);
% surf(X, Y ,Z);

















% figure(1);
% plot(test1(:,1),test1(:,2),'.');
% axis([-8 8 -8 8]);
% 
% figure(2);
% plot(test2(:,1),test2(:,2),'.');
% axis([-8 8 -8 8]);
% 
% figure(3);
% plot(test3(:,1),test3(:,2),'.');
% axis([-8 8 -8 8]);
% 
% figure(4);
% plot(X1(:,1),X1(:,2),'.');
% axis([-8 8 -8 8]);
% 
% figure(5);
% plot(X2(:,1),X2(:,2),'.');
% axis([-8 8 -8 8]);
% 
% figure(6);
% plot(X3(:,1),X3(:,2),'.');
% axis([-8 8 -8 8]);



% �̰� �׳� �ѹ� �غ���
% figure(4);
% plot(mv1, '.');
% axis([0 200 -0.5 0.5]);

% figure(5);
% plot(X2(:,1),X2(:,2),'.');
% axis([-8 8 -8 8]);
% 
% figure(6);
% plot(X3(:,1),X3(:,2),'.');
% axis([-8 8 -8 8]);
