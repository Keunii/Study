test_3

% pxw1 = (mv1*pw1)/px;
% pxw2 = (mv2*pw2)/px;
% pxw3 = (mv3*pw3)/px;

% bayes classifier
for i=1:size(XY, 1)
    PX = px(i);
    
    MV1 = mv1(i);
    MV2 = mv2(i);
    MV3 = mv3(i);
    
end
    pw1x = MV1*pw1/PX;
    pw2x = MV2*pw2/PX;
    pw3x = MV3*pw3/PX;
    
% likelihood
for i=1:size(XY, 1)
    PX = px(i);
    
    MV1 = mv1(i);
    MV2 = mv2(i);
    MV3 = mv3(i);
end

PMV1 = MV1 - MV2;
PMV2 = MV2 - MV3;
PMV3 = MV3 - MV1;